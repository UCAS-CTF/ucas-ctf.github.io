<?php

session_start();

// 检查用户的 cookie 是否存在
if (isset($_COOKIE['username']) && isset($_COOKIE['password'])) {
    // 获取 cookie 中的用户名和密码
    $username = $_COOKIE['username'];
    $password = $_COOKIE['password'];

    // 连接到 SQLite 数据库
    $db = new SQLite3('my_database.db');

    // 防止 SQL 注入
    $username = $db->escapeString($username);

    // 查询数据库检查用户名和密码是否匹配
    $stmt = $db->prepare('SELECT * FROM users WHERE username = :username');
    $stmt->bindValue(':username', $username, SQLITE3_TEXT);
    $result = $stmt->execute();

    // 检查查询结果
    $user = $result->fetchArray();
    if ($user) {
        // 检查密码是否匹配
        if ($user['password'] == $password) {
            // 登录成功，继续显示页面
            $_SESSION['username'] = $username;
            echo "欢迎, " . $_COOKIE['username'] . "！您已经成功登录。<br>";
        } else {
            // 密码不匹配，跳转到登录页面
            header("Location: login.html");
            exit();
        }
    } else {
        // 用户名不存在，跳转到登录页面
        header("Location: login.html");
        exit();
    }

    // 关闭数据库连接
    $db->close();
} else {
    // 如果没有 cookie，则跳转到登录页面
    header("Location: login.html");
    exit();
}

// 配置：模拟数据库（文件存储）
$db_file = 'comments.txt';

if (!file_exists($db_file)) {
    file_put_contents($db_file, "id,username,content,created_at\n");
}

// 处理表单提交（存储恶意数据）
$content = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $content = $_POST['content'] ?? ''; // 获取用户输入（未过滤）
    $created_at = date('Y-m-d H:i:s');
    
    // 将数据写入文件（模拟数据库插入）
    $line = "{$username},{$content},{$created_at}\n"; // 保存用户名和评论内容
    file_put_contents($db_file, $line, FILE_APPEND);
    
    // 提示提交成功（引导用户查看结果）
    echo "<script>alert('评论提交成功！');</script>";
}

// 读取所有评论（模拟数据显示）
$comments = [];
if (file_exists($db_file)) {
    $lines = file($db_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $index => $line) {
        if ($index === 0) continue; // 跳过表头
        list($user, $content, $created_at) = explode(',', $line, 3);
        $comments[] = [
            'username' => $user,
            'content' => $content,
            'created_at' => $created_at
        ];
    }
}

?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>留言板</title>
    <style>
        body { font-family: '微软雅黑', sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
        .comment-form { margin-bottom: 30px; padding: 20px; border: 1px solid #eee; border-radius: 8px; }
        .comment-form textarea { width: 100%; height: 100px; padding: 10px; margin-bottom: 10px; border: 1px solid #ddd; border-radius: 4px; }
        .comment-form button { padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; }
        .comment-form button:hover { background: #0056b3; }
        .comment-list { margin-top: 20px; }
        .comment-item { padding: 15px; border: 1px solid #eee; border-radius: 8px; margin-bottom: 10px; }
        .comment-item .content { margin-bottom: 5px; }
        .comment-item .created_at { font-size: 12px; color: #888; }
        .warning { background: #fff3cd; border: 1px solid #ffeeba; padding: 15px; border-radius: 8px; margin-top: 20px; color: #856404; }
        .warning h3 { margin-bottom: 10px; }
    </style>
</head>
<body>
    <h1>评论板</h1>
    
    <!-- 输入表单（未过滤） -->
    <div class="comment-form">
        <h2>发表评论</h2>
        <form method="post" action="">
            <textarea name="content" placeholder="请输入评论内容" required><?= $content ?></textarea> <!-- 清空后不会保留提交的数据 -->
            <button type="submit">提交评论</button>
        </form>
    </div>
    
    <!-- 显示评论（未过滤） -->
    <div class="comment-list">
        <h2>评论列表</h2>
        <?php if (empty($comments)): ?>
            <p>暂无评论</p>
        <?php else: ?>
            <?php foreach ($comments as $comment): ?>
                <div class="comment-item">
                    <div class="username"><?= $comment['username'] ?>：</div> <!-- 显示用户名 -->
                    <div class="content"><?= $comment['content'] ?></div> <!-- 显示评论内容 -->
                    <div class="created_at">发布时间：<?= $comment['created_at'] ?></div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>
</html>
