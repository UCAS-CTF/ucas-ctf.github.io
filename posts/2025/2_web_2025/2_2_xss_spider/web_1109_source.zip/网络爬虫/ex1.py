import requests
from lxml import etree

domain = "https://bkjy.ucas.ac.cn/tzgg"


i=0
while True:
    i += 10
    url = domain + f"?start={i}"
    response = requests.get(url).text
    tree = etree.HTML(response)
    time = [t.text.strip() for t in tree.xpath('//ul[@class="b-list"]//span')]
    if time == []:
        break
    notice = [n.text.strip() for n in tree.xpath('//ul[@class="b-list"]//a')]
    href = [domain + n for n in tree.xpath('//ul[@class="b-list"]//a/@href')]
    with open("notice.txt", "a", encoding="utf-8") as f:
        for t, n, h in zip(time, notice, href):
            f.write(f"{t}  {n}  {h}\n")
