from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5
import base64
import requests
from lxml import etree
import smtplib
from email.mime.text import MIMEText
from email.utils import formataddr

def send_email(my_sender="xxxxx",password="xxxxxxx"):    #分别填你的邮箱和邮箱授权码
    my_sender=my_sender    # 发件人邮箱账号
    my_pass = password     # 发件人邮箱密码或授权码(针对于QQ邮箱)
    my_user=my_sender      # 收件人邮箱账号,发送给自己
    def mail():
        ret=True
        try:
            msg=MIMEText('讲座更新了！！！','plain','utf-8')
            msg['From']=formataddr(["机器人",my_sender])  # 括号里的对应发件人邮箱昵称、发件人邮箱账号
            msg['To']=formataddr(["Dear Cat",my_user])   # 括号里的对应收件人邮箱昵称、收件人邮箱账号
            msg['Subject']="讲座更新提示"                # 邮件的主题，也可以说是标题

            server=smtplib.SMTP_SSL("smtp.qq.com", 465)  # 发件人邮箱中的SMTP服务器，端口是465
            server.login(my_sender, my_pass)  # 括号中对应的是发件人邮箱账号、邮箱密码
            server.sendmail(my_sender,[my_user,],msg.as_string())  # 括号中对应的是发件人邮箱账号、收件人邮箱账号、发送邮件
            server.quit()  # 关闭连接
        except Exception:  # 如果 try 中的语句没有执行，则会执行下面的 ret=False
            ret=False
        return ret
    
    ret=mail()
    if ret:
        print("邮件发送成功")
    else:
        print("邮件发送失败")

jse_pub_key = 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxG1zt7VW/VNk1KJC7AuoInrMZKTf0h6S6xBaROgCz8F3xdEIwdTBGrjUKIhIFCeDr6esfiVxUpdCdiRtqaCS9IdXO+9Fs2l6fx6oGkAA9pnxIWL7bw5vAxyK+liu7BToMFhUdiyRdB6erC1g/fwDVBywCWhY4wCU2/TSsTBDQhuGZzy+hmZGEB0sqgZbbJpeosW87dNZFomn/uGhfCDJzswjS/x0OXD9yyk5TEq3QEvx5pWCcBJqAoBfDDQy5eT3RR5YBGDJODHqW1c2OwwdrybEEXKI9RCZmsNyIs2eZn1z1Cw1AdR+owdXqbJf9AnM3e1CN8GcpWLDyOnaRymLgQIDAQAB'

# 将 base64 公钥包装为 PEM
pem = "-----BEGIN PUBLIC KEY-----\n" + jse_pub_key + "\n-----END PUBLIC KEY-----"

rsa_key = RSA.import_key(pem)
cipher = PKCS1_v1_5.new(rsa_key)

userName = "xxxxxx"  # 把 userName 替换为你的sep用户名
pwd1 = "xxxxxx"  # 把 pwd1 替换为你的明文密码
encrypted = cipher.encrypt(pwd1.encode('utf-8'))

passwordRSA = base64.b64encode(encrypted).decode('utf-8')

sep_url = "https://sep.ucas.ac.cn"
url_login = sep_url + "/slogin"
s = requests.Session()
s.post(url_login, data={'userName': userName, 'pwd': passwordRSA, 'loginFrom': '/appStoreStudent', 'sb': 'sb'})  

url_class = sep_url + "/portal/site/524/2412"

response1 = s.get(url_class)
tree1 = etree.HTML(response1.text)
redirect_url = tree1.xpath('//div[@class="row-fluid"]//a/@href')[0]
print(redirect_url)
response2 = s.get(redirect_url)
tree2 = etree.HTML(response2.text)
lecture_url = tree2.xpath('//a[text()="讲座预告"]/@href')[1]  #人文讲座而非科研讲座
response3 = s.get(lecture_url)
tree3 = etree.HTML(response3.text)
final_url = tree3.xpath('//div[@class="row-fluid"]//h4/a/@href')[0]
response4 = s.get(final_url)
tree4 = etree.HTML(response4.text)
lecture = tree4.xpath('//table[@class="table table-striped table-bordered table-advance table-hover"]//tr//td')[1].text.strip()
try:
    with open("lecture.txt", "r", encoding="utf-8") as f:
        old_lecture = f.read().strip()
    if lecture != old_lecture:
        with open("lecture.txt", "w", encoding="utf-8") as f:
            f.write(lecture)
        send_email()
except FileNotFoundError:
    with open("lecture.txt", "w", encoding="utf-8") as f:
        f.write(lecture)
        send_email()


