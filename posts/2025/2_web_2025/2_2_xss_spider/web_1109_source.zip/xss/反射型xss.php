<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>反射型XSS测试</title>
</head>
<body>
    <h1>反射型XSS测试页面</h1>
     <p>get参数为msg</p>
    <?php
    // 接收用户输入（未过滤）
    if (isset($_GET['msg'])) {
        $msg = $_GET['msg']; // 直接获取URL参数
        echo "<div class='output'>您输入的内容：$msg</div>"; // 未过滤直接输出
    }
    ?>
    <p>测试示例：</p>
    <p>基础弹窗：&lt;script&gt;alert('XSS')&lt;/script&gt;；</p>
    <p>图片onerror事件：&lt;img src="x" onerror="alert('XSS')"&gt;</p>
    <p>SVG标签：&lt;svg onload="alert('XSS')"&gt;；</p>
</body>
</html>