<?php
// SQLite 数据库文件
$db_file = 'my_database.db'; // 数据库文件名

// 连接到 SQLite 数据库
$db = new SQLite3($db_file);

// 检查数据库是否连接成功
if (!$db) {
    die("数据库连接失败: " . $db->lastErrorMsg());
}

// 检查表是否存在，如果不存在则创建
$table_check_sql = "SELECT name FROM sqlite_master WHERE type='table' AND name='users'";
$result = $db->query($table_check_sql);

if ($result->fetchArray() === false) {
    // 创建表
    $create_table_sql = "CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        password TEXT NOT NULL
    )";
    
    if (!$db->exec($create_table_sql)) {
        die("表创建失败: " . $db->lastErrorMsg());
    } else {
        echo "表创建成功！<br>";
    }
}

// 如果表单已提交
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    // 防止 SQL 注入
    $user = $db->escapeString($user);
    $pass = $db->escapeString($pass);

    // 查询数据库检查用户名是否存在
    $sql = "SELECT * FROM users WHERE username='$user'";
    $result = $db->query($sql);

    if ($result->fetchArray() !== false) {
        // 用户名存在，验证密码
        $stmt = $db->prepare('SELECT password FROM users WHERE username=:username');
        $stmt->bindValue(':username', $user, SQLITE3_TEXT);
        $password_row = $stmt->execute()->fetchArray();
        
        if ($password_row['password'] == $pass) {
            // 密码正确，登录成功
            session_start();
            $_SESSION['username'] = $user;

            // 设置账号与密码的 Cookie（记住用户1天）
            setcookie('username', $user, time() + 86400, '/');
            setcookie('password', $pass, time() + 86400, '/');

            // 跳转到index.html
            header("Location: index.php");
            exit();
        } else {
            // 密码错误
            echo "密码错误";
        }
    } else {
        // 用户名不存在，直接注册并登录
        $stmt = $db->prepare('INSERT INTO users (username, password) VALUES (:username, :password)');
        $stmt->bindValue(':username', $user, SQLITE3_TEXT);
        $stmt->bindValue(':password', $pass, SQLITE3_TEXT);

        if ($stmt->execute()) {
            // 注册成功，直接登录
            session_start();
            $_SESSION['username'] = $user;

            // 设置账号与密码的 Cookie（记住用户1天）
            setcookie('username', $user, time() + 86400, '/');
            setcookie('password', $pass, time() + 86400, '/');

            // 跳转到index.html
            header("Location: index.html");
            exit();
        } else {
            // 插入失败
            echo "注册失败: " . $db->lastErrorMsg();
        }
    }
}

// 关闭数据库连接
$db->close();
?>
