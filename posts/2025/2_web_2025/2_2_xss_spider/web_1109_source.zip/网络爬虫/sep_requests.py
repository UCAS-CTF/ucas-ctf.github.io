import requests
from lxml import etree
import re

url = "https://sep.ucas.ac.cn"

response = requests.get(url).text

tree = etree.HTML(response)
'''
links = tree.xpath("//*[@href]")         #找到所有链接
for link in links:
    href = link.get("href")
    print(href)
'''



regex = re.compile(r'/.*(?:png|jpe?g|gif|bmp)', re.IGNORECASE)  #正则表达式
image_links = regex.findall(response)
for img in image_links:
    print(img)


with open("sep_requests.html", "w", encoding="utf-8") as file:
    file.write(response)
