# pip install pycryptodome
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5
import base64
import requests

jse_pub_key = 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxG1zt7VW/VNk1KJC7AuoInrMZKTf0h6S6xBaROgCz8F3xdEIwdTBGrjUKIhIFCeDr6esfiVxUpdCdiRtqaCS9IdXO+9Fs2l6fx6oGkAA9pnxIWL7bw5vAxyK+liu7BToMFhUdiyRdB6erC1g/fwDVBywCWhY4wCU2/TSsTBDQhuGZzy+hmZGEB0sqgZbbJpeosW87dNZFomn/uGhfCDJzswjS/x0OXD9yyk5TEq3QEvx5pWCcBJqAoBfDDQy5eT3RR5YBGDJODHqW1c2OwwdrybEEXKI9RCZmsNyIs2eZn1z1Cw1AdR+owdXqbJf9AnM3e1CN8GcpWLDyOnaRymLgQIDAQAB'

# 将 base64 公钥包装为 PEM
pem = "-----BEGIN PUBLIC KEY-----\n" + jse_pub_key + "\n-----END PUBLIC KEY-----"

rsa_key = RSA.import_key(pem)
cipher = PKCS1_v1_5.new(rsa_key)

pwd1 = "xxxxxxx"  # 把 pwd1 替换为你的明文密码
encrypted = cipher.encrypt(pwd1.encode('utf-8'))

# 与 JSEncrypt 行为一致，输出 base64 字符串
passwordRSA = base64.b64encode(encrypted).decode('utf-8')

url_login = "https://sep.ucas.ac.cn/slogin"
s = requests.Session()
response=s.post(url_login, data={'userName': 'xxxxxxx', 'pwd': passwordRSA, 'loginFrom': '/appStoreStudent', 'sb': 'sb'})                           # 登录
print(response.url)
with open("2_1.html", "w", encoding="utf-8") as f:
    f.write(response.text)

url_businessmenu = "https://sep.ucas.ac.cn/businessMenu"
response2 = s.get(url_businessmenu)  # 访问业务菜单
with open("2_2.html", "w", encoding="utf-8") as f:
    f.write(response2.text)

url_usercommon = "https://sep.ucas.ac.cn/userCommon8"
response3 = s.get(url_usercommon)  
with open("2_3.html", "w", encoding="utf-8") as f:
    f.write(response3.text)